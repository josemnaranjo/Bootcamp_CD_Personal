const video = document.getElementById("videoFoca");


function playVideo() {
    video.play();
}


function stopVideo() {
    video.pause();

}